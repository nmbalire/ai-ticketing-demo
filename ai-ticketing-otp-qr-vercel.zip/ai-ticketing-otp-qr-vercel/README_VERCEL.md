
# Deploy to Vercel

## Using the Dashboard (no CLI)
1. Create a new GitHub repository and upload the **contents of this folder** (keep files at the repo root).
2. Go to https://vercel.com -> **Add New** -> **Project**.
3. Import your repo.
4. **Framework Preset**: *Other*.
5. **Build Command**: *(leave empty)*.
6. **Output Directory**: `.`
7. Deploy. Your URL will look like `https://<project>.vercel.app/`.

Entry pages after deploy:
- Sign-in (OTP demo): `/index.html`
- Organizer dashboard: `/dashboard.html`
- Attendee wallet: `/attendee.html`

## Using the CLI (fastest)
```bash
npm i -g vercel
unzip ai-ticketing-otp-qr-vercel.zip
cd ai-ticketing-otp-qr-vercel
vercel --prod
```
Vercel will print a URL like `https://<project>.vercel.app/`.
Open:
- `https://<project>.vercel.app/index.html`
- `https://<project>.vercel.app/dashboard.html`
- `https://<project>.vercel.app/attendee.html`
